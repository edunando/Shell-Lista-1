#!/bin/bash

DIR="$1"
DIR2="$2"

echo 'Exibindo diretórios'
ls ${DIR} ${DIR2}


