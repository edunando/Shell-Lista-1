#!/bin/bash

echo 'Ninguém vai bater tão forte como a vida, mas a questão não é o quão forte você consegue bater. É o quão forte você consegue apanhar e continuar seguindo em frente.'


