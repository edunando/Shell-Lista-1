#!/bin/bash

read -p "Escreva aqui os nomes dos diretórios que você deseja listar:" dir1 dir2 

ls ${dir1} ${dir2}

